create
    definer = root@localhost procedure refund(OUT result_out varchar(10), IN prescription_id_in int, IN invoice_in int,
                                              IN user_in int)
BEGIN
DECLARE
	temp_register_id INT;#挂号id
DECLARE
	temp_drug_id INT;#药品id
DECLARE
	temp_name VARCHAR ( 40 );#药品名称
DECLARE
	temp_price DOUBLE;#价格
DECLARE
	temp_quantity INT;#数量
DECLARE
	temp_invoice INT;#红冲发票号
DECLARE
	temp_status INT;#药品缴费状态
DECLARE
	temp_amount DOUBLE DEFAULT 0;
DECLARE
	done BOOLEAN DEFAULT 0;
DECLARE#游标
cur CURSOR FOR SELECT
drug,
quantity,
charge_status 
FROM
	prescription_item 
WHERE
	prescription_id = prescription_id_in 
	AND isDeleted = 0;
DECLARE
	CONTINUE HANDLER FOR NOT FOUND 
	SET done = 1;
START TRANSACTION;
SELECT register_id INTO temp_register_id FROM prescription WHERE id = prescription_id_in;
IF
	 temp_register_id = NULL 
	OR ( SELECT id FROM invoice WHERE invoice_id = invoice_in ) = NULL THEN
	
	SET result_out = "操作成功";
ROLLBACK;

END IF;
SELECT
	Max( invoice_id ) INTO temp_invoice 
FROM
	invoice;#获取红冲发票号
SET temp_invoice = temp_invoice + 1;
OPEN cur;
read_loop :
LOOP
		FETCH cur INTO temp_drug_id,
		temp_quantity,
		temp_status;
	IF
		done = 1 THEN
			LEAVE read_loop;
		
	END IF;
	IF
		temp_status = 1 
		OR temp_status = 3 THEN#跳过未缴费或已退费的项目
			ITERATE read_loop;
		
	END IF;
	SELECT
		DrugsName,
		DrugsPrice INTO temp_name,
		temp_price 
	FROM
		drugs 
	WHERE
		id = temp_drug_id;
	
	SET temp_price = - temp_price;
	INSERT INTO charges_details ( register_id, project, project_type, `name`, price, quantity, time, `user`, invoice ,type)
	VALUES
		( temp_register_id, temp_drug_id, 1, temp_name, temp_price, temp_quantity, NOW( ), user_in, temp_invoice ,0);
	
	SET temp_amount = temp_amount + temp_price * temp_quantity;
	
END LOOP;
CLOSE cur;
INSERT INTO invoice ( invoice_id, amount, time, `user` )
VALUES
	( temp_invoice, temp_amount, NOW( ), user_in );#增加红冲发票
UPDATE invoice 
SET red_invoice = temp_invoice 
WHERE
	invoice_id = invoice_in 
	AND isDeleted = 0;#更新发票的红冲发票号码

SET result_out = "操作成功";
COMMIT;

END;

