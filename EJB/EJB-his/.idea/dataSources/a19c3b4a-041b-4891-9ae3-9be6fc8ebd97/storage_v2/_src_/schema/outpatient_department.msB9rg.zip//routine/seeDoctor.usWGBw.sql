create
    definer = root@localhost procedure seeDoctor(OUT result_out varchar(255), IN register_id_in int,
                                                 IN chief_complaint_in text, IN history_present_illness_in text,
                                                 IN past_history_in text, IN allergic_history_in text,
                                                 IN health_checkup_in text, IN primary_diagnosis_in text,
                                                 IN diagnosis_type_in text, IN checkup_advice_in text,
                                                 IN announcements_in text)
label : BEGIN
DECLARE
	current_medical_record_num INT;
DECLARE
	current_status INT;
START TRANSACTION;
SELECT#挂号id查询病历号
	medical_record_num INTO current_medical_record_num 
FROM
	register_info 
WHERE
	id = register_id_in 
	AND isDeleted = 0;
SELECT#病历号查询病历状态
	medical_record_status INTO current_status 
FROM
	medical_record 
WHERE
	medical_record_num = current_medical_record_num 
	AND isDeleted = 0;
	SET result_out = "未操作";
IF
current_medical_record_num=NULL#未查询到病历号或者诊毕将不能再修改信息
	OR current_status = 3 THEN
	
	SET result_out = "操作失败";
	ROLLBACK;
LEAVE label;#终止

ELSEIF current_status = 1 
OR current_status = 2 THEN#暂存了信息或者已提交 需要更新病历信息
	UPDATE medical_record 
	SET chief_complaint = chief_complaint_in,
	history_present_illness = history_present_illness_in,
	past_history = past_history_in,
	allergic_history = allergic_history_in,
	health_checkup = health_checkup_in,
	primary_diagnosis = primary_diagnosis_in,
	diagnosis_type = diagnosis_type_in,
	checkup_advice = checkup_advice_in,
	announcements = announcements_in ,
	medical_record_status = 3
	WHERE
		medical_record_num = current_medical_record_num 
		AND isDeleted = 0;
	
	SET result_out = "操作成功";
  COMMIT;
ELSEIF IFNULL(current_status,-1) THEN#没有记录就诊毕直接添加数据
INSERT INTO medical_record ( register_id, medical_record_num, chief_complaint, history_present_illness, past_history, allergic_history, health_checkup, primary_diagnosis, diagnosis_type, checkup_advice, announcements,medical_record_status )
VALUES
	( register_id_in, current_medical_record_num, chief_complaint_in, history_present_illness_in, past_history_in, allergic_history_in, health_checkup_in, primary_diagnosis_in, diagnosis_type_in, checkup_advice_in, announcements_in ,3);

SET result_out = "操作成功";
COMMIT;
END IF;
UPDATE register_info #更新挂号信息为已诊
SET `status` = 2 
WHERE
	id = register_id_in ;
END;

