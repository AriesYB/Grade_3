create
    definer = root@localhost procedure unregister(OUT result_out varchar(10), IN register_id_in int(10))
BEGIN
DECLARE
	current_status INT;
START TRANSACTION;
SELECT
	`status` INTO current_status 
FROM
	register_info 
WHERE
	id = register_id_in;
IF
	current_status = 1 THEN
	UPDATE register_info 
	SET `status` = 3 
WHERE
	id = register_id_in;

SET result_out = "操作成功";
COMMIT;

ELSEIF current_status = 2 THEN

SET result_out = "操作失败";
ROLLBACK;

ELSEIF current_status = 3 THEN

SET result_out = "操作失败";
ROLLBACK;

END IF;

END;

