create
    definer = root@localhost procedure dispenseDrug(OUT result_out varchar(10), IN medical_record_num_in int)
BEGIN
DECLARE
	temp_prescription_id INT;
DECLARE
	temp_status INT;
START TRANSACTION;
SELECT
	id INTO temp_prescription_id 
FROM
	prescription 
WHERE
	medical_record_num = medical_record_num_in 
	AND isDeleted = 0;
SELECT
	`status` INTO temp_status 
FROM
	prescription_item 
WHERE
	prescription_id = temp_prescription_id 
	AND isDeleted = 0;
IF
	temp_status = 1 THEN
	UPDATE prescription_item 
	SET `status` = "2" 
WHERE
	prescription_id = temp_prescription_id 
	AND isDeleted = 0;
	SET result_out = "操作成功";
	COMMIT;
ELSE 
	SET result_out = "操作失败";
ROLLBACK;

END IF;

END;

