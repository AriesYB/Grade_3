create
    definer = root@localhost procedure register(OUT result_out varchar(255), IN ID_number_in char(255),
                                                IN name_in varchar(255), IN sex_in int, IN date_birth_in date,
                                                IN age_in int, IN address_in varchar(255), IN see_doctor_time_in date,
                                                IN am_or_pm_in varchar(255), IN department_in int, IN doctor_in int,
                                                IN register_class_in int, IN settlement_type_in varchar(255),
                                                IN is_need_book_in int, IN register_user_in int)
BEGIN
DECLARE
	`current_time` datetime DEFAULT NOW( );
DECLARE
	old_id_number CHAR ( 18 );
DECLARE
	old_sex CHAR ( 2 );
DECLARE
	old_name,
	old_address VARCHAR ( 40 );
DECLARE
	old_isDeleted INT;
DECLARE
	current_date_birth date;
DECLARE
	current_age INT;#计算生日或者年龄
DECLARE
	medical_record_num_new INT;
DECLARE
	num INT;
IF
	age_in = - 1 THEN
	
	SET current_date_birth = date_birth_in;

SET current_age = FLOOR( ( DATEDIFF( CURRENT_DATE ( ), current_date_birth ) ) / 365 );
ELSE 
	SET current_date_birth = DATE_SUB( CURRENT_DATE, INTERVAL age_in YEAR );

SET current_age = age_in;

END IF;
START TRANSACTION;
SELECT
	ID_number,
	`name`,
	sex,
	address,
	isDeleted INTO old_id_number,
	old_name,
	old_sex,
	old_address,
	old_isDeleted 
FROM
	patient 
WHERE
	ID_number = ID_number_in;#如果查到了信息且不相同删除原来的病人信息再添加新的
IF
	old_id_number = ID_number_in 
	AND old_isDeleted = 0 THEN
	IF
		! ( old_name = name_in AND old_sex = sex_in AND old_address = address_in AND current_date_birth = date_birth_in AND current_age = age_in ) THEN
			UPDATE patient 
			SET isDeleted = 1 
		WHERE
			ID_number = old_id_number;#添加病人
		INSERT INTO patient ( `name`, sex, ID_number, date_birth, age, address )
		VALUES
			( name_in, sex_in, ID_number_in, date_birth_in, age_in, address_in );
		
	END IF;
	ELSE #添加病人
	INSERT INTO patient ( `name`, sex, ID_number, date_birth, age, address )
	VALUES
		( name_in, sex_in, ID_number_in, current_date_birth, current_age, address_in );
	
END IF;
SELECT
	MAX( medical_record_num ) INTO medical_record_num_new 
FROM
	register_info;

SET medical_record_num_new = medical_record_num_new + 1;#生成病历号
#添加挂号信息
INSERT INTO register_info ( ID_number, medical_record_num, settlement_type, register_class, department, doctor, is_need_book, time, see_doctor_time, am_or_pm, register_user )
VALUES
	( ID_number_in, medical_record_num_new, settlement_type_in, register_class_in, department_in, doctor_in, is_need_book_in, `current_time`, see_doctor_time_in, am_or_pm_in, "110" );
SELECT
	COUNT( * ) INTO num 
FROM
	register_info 
WHERE
	medical_record_num = medical_record_num_new;
IF
	num = 0 THEN
		
		SET result_out = "操作失败";
	ROLLBACK;
	
	ELSEIF num = 1 THEN
	
	SET result_out = "操作成功";
	COMMIT;
	
END IF;

END;

