create
    definer = root@localhost procedure charge(OUT result_out varchar(10), IN prescription_id_in int, IN user_id_in int)
BEGIN
DECLARE
	temp_prescription_id INT;
DECLARE
	temp_register_id INT;
DECLARE
	temp_drug_id INT;
DECLARE
	temp_drug_name VARCHAR ( 20 );
DECLARE
	temp_price DOUBLE;
DECLARE
	temp_quantity INT;
DECLARE
	done INT DEFAULT FALSE;
DECLARE
	temp_invoice_id INT;
DECLARE
	temp_amount DOUBLE DEFAULT 0;
DECLARE 
	cur CURSOR FOR SELECT
	drug,
	quantity 
FROM
	prescription_item 
WHERE
	prescription_id = prescription_id_in;
DECLARE
	CONTINUE HANDLER FOR NOT FOUND 
	SET done = 1;
START TRANSACTION;
SELECT
	id,register_id INTO temp_prescription_id,temp_register_id
FROM
	prescription 
WHERE
	id = prescription_id_in;
#SELECT register_id INTO temp_register_id FROM medical_record WHERE medical_record_num = temp_medical_record_id AND isDeleted = 0;
IF
	temp_register_id = NULL THEN
	
	SET result_out = "操作失败";
ROLLBACK;

END IF;
SELECT
	MAX( invoice_id ) INTO temp_invoice_id 
FROM
	invoice;
IF temp_invoice_id=NULL THEN
SET temp_invoice_id = 800801;
ELSE
SET temp_invoice_id = temp_invoice_id + 1;
END IF;
OPEN cur;
read_loop :
LOOP
		FETCH cur INTO temp_drug_id,
		temp_quantity;
	IF
		done=1 THEN
			LEAVE read_loop;
		
	END IF;
	SELECT
		DrugsName,
		DrugsPrice INTO temp_drug_name,
		temp_price 
	FROM
		drugs 
	WHERE
		id = temp_drug_id;
	INSERT INTO charges_details ( register_id, project, project_type, `name`, price, quantity, time, `user`, invoice )
	VALUES
		( temp_register_id, temp_drug_id, 1, temp_drug_name, temp_price, temp_quantity, NOW( ), user_id_in, temp_invoice_id );
	UPDATE prescription_item 
	SET charge_status = 2 
	WHERE
		drug = temp_drug_id;
	
	SET temp_amount = temp_amount + temp_price * temp_quantity;
	
END LOOP read_loop;
CLOSE cur;
INSERT INTO invoice ( invoice_id, amount, `status`, time, `user` )
VALUES
	( temp_invoice_id, temp_amount, 1, NOW( ), user_id_in );
	SET result_out = "操作成功";
COMMIT;

END;

