create
    definer = root@localhost procedure writePrescription(OUT result_out varchar(10), IN register_id_in int,
                                                         IN prescription_name_in varchar(20), IN drug_in varchar(255))
BEGIN
DECLARE
	current_medical_record_num INT;
DECLARE
	current_doctor INT;
DECLARE
	current_diagnosis_type INT;#中西医
DECLARE
	temp_drug_format VARCHAR ( 10 );
DECLARE
	temp_prescription_id INT;
START TRANSACTION;
SELECT
	medical_record_num,
	doctor INTO current_medical_record_num,
	current_doctor 
FROM
	register_info 
WHERE
	id = register_id_in 
	AND isDeleted = 0;
SELECT
	diagnosis_type INTO current_diagnosis_type 
FROM
	medical_record 
WHERE
	medical_record_num = current_medical_record_num 
	AND isDeleted = 0;
IF
	current_medical_record_num=NULL THEN
	
	SET result_out = "操作失败";
ROLLBACK;
ELSE SELECT#获取处方id
MAX( id ) INTO temp_prescription_id 
FROM
	prescription 
WHERE
	register_id = register_id_in 
	AND isDeleted = 0;
IF
	temp_prescription_id=NULL THEN
		
		SET temp_prescription_id = 1;
	ELSE 
		SET temp_prescription_id = temp_prescription_id + 1;
	
END IF;
INSERT INTO prescription ( medical_record_num, register_id, doctor, type, `name`, time, `status` )
VALUES
	(current_medical_record_num, register_id_in, current_doctor, current_diagnosis_type, prescription_name_in, NOW( ), '1' );

SET @i = 0;

SET @arraylength = 1 + LENGTH( drug_in ) - LENGTH( REPLACE ( drug_in, ",", "" ) );
WHILE#i个处方明细
	@i < @arraylength DO
	
	SET @i = @i + 1;
	
	SET @result = REVERSE( SUBSTRING_INDEX( REVERSE( SUBSTRING_INDEX( drug_in, ',', @i ) ), ',', 1 ) );#分割每个药品的信息
	
	SET @sql_insert = CONCAT( "INSERT INTO prescription_item (prescription_id,drug,`usage`,consumption,consumption_unit,frequency,quantity) VALUES (", temp_prescription_id, ",?,?,?,?,?,?);" );
	
	SET @drug = REVERSE( SUBSTRING_INDEX( REVERSE( SUBSTRING_INDEX( @result, '=', 1 ) ), '=', 1 ) );
	
	SET @`usage` = REVERSE( SUBSTRING_INDEX( REVERSE( SUBSTRING_INDEX( @result, '=', 2 ) ), '=', 1 ) );
	
	SET @consumption = REVERSE( SUBSTRING_INDEX( REVERSE( SUBSTRING_INDEX( @result, '=', 3 ) ), '=', 1 ) );
	
	SET @consumption_unit = REVERSE( SUBSTRING_INDEX( REVERSE( SUBSTRING_INDEX( @result, '=', 4 ) ), '=', 1 ) );
	
	SET @frequency = REVERSE( SUBSTRING_INDEX( REVERSE( SUBSTRING_INDEX( @result, '=', 5 ) ), '=', 1 ) );
	
	SET @quantity = REVERSE( SUBSTRING_INDEX( REVERSE( SUBSTRING_INDEX( @result, '=', 6 ) ), '=', 1 ) );
	PREPARE stmt 
	FROM
		@sql_insert;
	EXECUTE stmt USING @drug,
	@`usage`,
	@consumption,
	@consumption_unit,
	@frequency,
	@quantity;
	DEALLOCATE PREPARE stmt;
	
END WHILE;

SET result_out = "操作成功";
COMMIT;

END IF;

END;

